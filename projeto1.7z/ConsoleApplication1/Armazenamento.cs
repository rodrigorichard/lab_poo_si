﻿namespace ConsoleApplication1
{
    internal class Armazenamento
    {
        private Fabricante fabricante;
    }
}