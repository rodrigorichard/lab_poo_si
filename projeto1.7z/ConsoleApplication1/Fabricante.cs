﻿namespace ConsoleApplication1
{
    internal class Fabricante
    {
    }
}