﻿namespace ConsoleApplication1
{
    internal class Processador
    {
        private Fabricante fabricante;
    }
}