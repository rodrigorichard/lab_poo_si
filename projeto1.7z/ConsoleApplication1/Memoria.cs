﻿namespace ConsoleApplication1
{
    internal class Memoria
    {
        private Fabricante fabricante;
    }
}