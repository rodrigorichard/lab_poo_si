﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora
{
    class Divisao : Operacao
    {
        public override int executar(int a, int b)
        {
            return a / b;
        }
    }
}
