﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora
{
    abstract class Operacao
    {
        public abstract int executar(int a, int b);
    }
}
