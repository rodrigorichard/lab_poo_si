﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora
{
    class Program
    {
        static void Main(string[] args)
        {
            Operacao op1 = new Soma();
            Operacao op2 = new Subtracao();
            Operacao op3 = new Multiplicacao();
            Operacao op4 = new Divisao();
            Operacao op5 = new Modulo();

            /*
            * Potencia
            * Fatorial
            * SQRT
            */

            Calculadora c = new Calculadora();
            c.calcular(op1, 10, 20);
            c.calcular(op2, 10, 20);
            c.calcular(op3, 10, 20);
            c.calcular(op4, 10, 20);
            c.calcular(op5, 104, 20);

            Console.ReadKey();
        }
    }
}
