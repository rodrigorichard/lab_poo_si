﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora
{
    class Calculadora
    {
      public void calcular(Operacao op, int a, int b)
        {
            Console.WriteLine(op.executar(a, b));
        }
    }
}
