﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections.Generic;

namespace ConsoleApplication2
{
    class Estado
    {
        private static Dictionary<int, Estado> estados =
            new Dictionary<int, Estado>();

        public int Id { get; set; }
        public string Nome { get; set; }
        public string Sigla { get; set; }

        public override string ToString()
        {
            return Nome + " - " + Sigla;
        }

        public static void lerBancoDeDados()
        {
            StreamReader arquivo = new
                StreamReader("z:\\base\\estados.csv");
            string linha;
            while((linha = arquivo.ReadLine()) != null)
            {
                String[] campos = linha.Split(',');
                Estado e = new Estado();
                e.Id = int.Parse(campos[0]);
                e.Nome = campos[1];
                e.Sigla = campos[2];
                estados.Add(e.Id, e);
            }
            arquivo.Close();
        }

        public static Estado getEstado(int id)
        {
            return estados[id];
        }
    }
}
