﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            Estado.lerBancoDeDados();
            Cidade.lerBancoDeDados();
            Endereco.lerBancoDeDados();

           

            Application.EnableVisualStyles();
            Application.Run(new TelaConsulta());



        }
    }
}
