﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApplication2
{
    class Cidade
    {
        private static Dictionary<int, Cidade> cidades = 
            new Dictionary<int, Cidade>();
        public int Id { get; set; }
        public String Nome { get; set; }

        public Estado Estado { get; set; }

        public override string ToString()
        {
            return Nome + " - " + Estado.Sigla;
        }

        public static void lerBancoDeDados()
        {
            StreamReader arquivo = new
              StreamReader("z:\\base\\cidades.csv");
            string linha;
            while ((linha = arquivo.ReadLine()) != null)
            {
                String[] campos = linha.Split(',');
                Cidade c = new Cidade();
                c.Id = int.Parse(campos[0]);
                c.Nome = campos[1];
                c.Estado = Estado.getEstado(int.Parse(campos[4]));
                cidades.Add(c.Id, c);
            }
            arquivo.Close();
        }

        public static Cidade getCidade(int id)
        {
            return cidades[id];
        }
      
    }
}
