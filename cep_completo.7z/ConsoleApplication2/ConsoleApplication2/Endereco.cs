﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApplication2
{
    class Endereco
    {
        public string Cep { get; set; }
        public string Nome { get; set; }
        public Cidade Cidade { get; set; }

        private static Dictionary<string, Endereco>
       enderecos = new Dictionary<string, Endereco>();

        public static void lerBancoDeDados()
        {
            StreamReader arquivo = new
                StreamReader("z:\\base\\enderecos.csv");
            string linha;
            while ((linha = arquivo.ReadLine()) != null)
            {
                String[] campos = linha.Split(',');
                Endereco e = new Endereco();
                e.Cep = campos[7];
                e.Nome = campos[4];
                e.Cidade = Cidade.getCidade(int.Parse(campos[2]));
                if (!enderecos.ContainsKey(e.Cep))
                {
                    enderecos.Add(e.Cep, e);
                }
                
            }
            arquivo.Close();
        }

        public static Endereco getEndereco(string cep)
        {
            return enderecos[cep];
        }

        public override string ToString()
        {
            return Nome + "," + Cidade;
        }
    }

    
}
